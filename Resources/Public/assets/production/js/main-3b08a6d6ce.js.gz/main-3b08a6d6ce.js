!function(){"use strict";console.log("test"),console.log("sffsffs"),console.log("sffsffs"),console.log("test")}();

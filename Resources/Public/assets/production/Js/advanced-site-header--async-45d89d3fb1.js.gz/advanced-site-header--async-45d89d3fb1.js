!function(){"use strict";const t=document.querySelectorAll("#dropdown-big-menu");0!==t.length&&t.forEach((t=>{t.addEventListener("click",(t=>{t.stopPropagation()}))}))}();

!function(){"use strict";window.global=window,window.Popper=()=>{}}();

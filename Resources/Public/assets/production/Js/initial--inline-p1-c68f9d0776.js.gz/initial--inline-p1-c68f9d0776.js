!function(){"use strict";window.global={},window.Popper=()=>{}}();

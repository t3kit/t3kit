!function(){"use strict";var e=document.querySelectorAll("#dropdown-big-menu");0!=e.length&&e.forEach((e=>{e.addEventListener("click",(e=>{e.stopPropagation()}))}))}();
